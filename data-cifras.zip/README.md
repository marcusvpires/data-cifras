
# Data cifras

Extensão para chrome e firefox que serve como uma extensão ao [cifra club](https://www.cifraclub.com.br). A Data cifra permite que você salve, edite e categorize as cifras, além de trazer várias ferramentas que ajudam a visualizar toda a cifra em quanto toca a musica.

![](media\screenshot\button.png)

![](media\screenshot\edicao.png)

![](media\screenshot\tela-cheia.png)

![](media\screenshot\modo-coluna.png)

![](media\screenshot\tabela.png)