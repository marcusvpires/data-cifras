console.log("script carregado")

const onError = (err) => console.log(err)

const getTargetCifra = () => {
    let gettingAllStorageItems = browser.storage.local.get("targetcifra");
    gettingAllStorageItems.then((results) => {
        const code = results.targetcifra.code
        var doc = new DOMParser().parseFromString(code, "text/html");
        document.querySelector("body").appendChild(doc.querySelector("pre"))
    }, onError);
}

getTargetCifra()